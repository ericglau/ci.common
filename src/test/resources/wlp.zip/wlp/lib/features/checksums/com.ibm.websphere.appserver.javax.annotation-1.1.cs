#Wed May 23 16:46:42 EDT 2018
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=30e0e3808766437cef74d5227cfe1007
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.21.jar=ffae54b365e350921a282e98193052a3
