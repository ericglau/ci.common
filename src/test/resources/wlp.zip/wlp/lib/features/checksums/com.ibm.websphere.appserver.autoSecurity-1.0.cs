#Wed May 23 16:46:42 EDT 2018
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=495c32f170e38884023ffa9b9332e107
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.21.jar=8b3866af7b7dd3298f137f6b74804b16
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=1d9d5227bc7fe40484217650c9962aa8
