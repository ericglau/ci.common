#Wed May 23 16:46:43 EDT 2018
dev/spi/ibm/com.ibm.websphere.appserver.spi.globalhandler_1.0.21.jar=3e2668b98e8eb0ec66435d0654b3662f
lib/features/com.ibm.websphere.appserver.globalhandler-1.0.mf=93a332a0963d11e5b25a8c028fa85b95
lib/com.ibm.ws.webservices.handler_1.0.21.jar=010c3d959a1943e88b5e06edeef3cd4f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.globalhandler_1.0-javadoc.zip=c66fb63b5e7cea4d934f45d8c91e304a
