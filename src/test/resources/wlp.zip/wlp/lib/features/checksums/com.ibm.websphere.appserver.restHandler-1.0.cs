#Wed May 23 16:46:43 EDT 2018
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=12f8ebb0bcc0fddad4bc7fec3c388c07
lib/com.ibm.ws.rest.handler_1.0.21.jar=514fbecbe6794f7877940219e16447ad
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.21.jar=fd076739ec5cc8165b50ae01405fb002
lib/com.ibm.websphere.jsonsupport_1.0.21.jar=bdf570b5ea1093a67f00748b02e3c433
lib/com.ibm.websphere.rest.handler_1.0.21.jar=7553615c907b3260ef191d7fe16d76b9
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=d1518d0177148b00bda3a0eeace32a67
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.21.jar=3d1f12283ffb6542959fd35c8d9a7cc5
