#Wed May 23 16:46:43 EDT 2018
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.21.jar=5faa140184497211e4adae7ec3caae08
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=a3a428bf973427b69fe50604f329b0ac
