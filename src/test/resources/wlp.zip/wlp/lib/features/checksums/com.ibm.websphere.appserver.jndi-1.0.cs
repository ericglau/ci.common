#Wed May 23 16:46:43 EDT 2018
lib/com.ibm.ws.jndi.url.contexts_1.0.21.jar=f88bbe25c980639eb99d7259bee942b3
lib/com.ibm.ws.jndi_1.0.21.jar=d5d94e9e229642ffee5bb054807507c4
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.21.jar=128d087e3b74a69fb799cca1aaebed45
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=aab9ca4f856d193df3040e66ad062cb8
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.21.jar=eea2a52da84cb2e6d0fec1819d2c3dd9
