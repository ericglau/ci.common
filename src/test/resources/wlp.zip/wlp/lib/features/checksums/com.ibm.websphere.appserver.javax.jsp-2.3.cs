#Wed May 23 16:46:42 EDT 2018
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.21.jar=9e7ab16a37542dbe24b2399b39c28d69
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=c115e4b48252258dadc4d9569a2e7b80
