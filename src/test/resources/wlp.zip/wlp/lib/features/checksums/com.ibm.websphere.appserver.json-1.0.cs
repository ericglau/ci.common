#Wed May 23 16:46:43 EDT 2018
lib/com.ibm.json4j_1.0.21.jar=691d624ba459435391a70da1810debfa
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=16e112f7ac384c61137aac72a19fc57b
lib/features/com.ibm.websphere.appserver.json-1.0.mf=898413ec162e956ba259a4edd3f1c0bc
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.21.jar=f8e9872342eca29a628b09faedf1decb
