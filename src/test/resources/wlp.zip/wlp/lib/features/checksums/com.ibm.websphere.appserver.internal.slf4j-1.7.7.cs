#Wed May 23 16:46:43 EDT 2018
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.21.jar=772974b04c975360fb23b14e35a58b92
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.21.jar=3473f65e6f5516f62a57bb1b32ce7a3e
lib/features/com.ibm.websphere.appserver.internal.slf4j-1.7.7.mf=7782bd76cc00de9177f316f4735f9ca4
