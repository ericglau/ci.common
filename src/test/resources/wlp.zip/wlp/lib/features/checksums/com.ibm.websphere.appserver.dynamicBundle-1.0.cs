#Wed May 23 16:46:42 EDT 2018
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=e9f6f77033e1c60fb697f9f7b2e1cade
lib/com.ibm.ws.dynamic.bundle_1.0.21.jar=c0b83432d2b2bdf7201a4588128a0621
