#Wed May 23 16:46:43 EDT 2018
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.21.jar=f868f8c6d2e639c7e4688dd042c2bd48
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=e5fc4ad4c1bc3fb97d6187f6df095ebe
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.21.jar=3221b882395900895a807ba5a4290a4a
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=883acb5f1720da1f246977560012f726
