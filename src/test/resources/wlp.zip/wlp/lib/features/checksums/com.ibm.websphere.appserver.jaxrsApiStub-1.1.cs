#Wed May 23 16:46:43 EDT 2018
lib/features/com.ibm.websphere.appserver.jaxrsApiStub-1.1.mf=5f56d6ad0ead2ef55613f887dba6df9f
dev/api/third-party/com.ibm.ws.jaxrs_1.1.21.jar=454f70e2432dc516c9cbfd50c3acfa39
