#Wed May 23 16:46:43 EDT 2018
lib/com.ibm.websphere.rest.api.discovery_1.0.21.jar=34300f654c6b4d87e8257d78b3bc701f
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=30d20934a4d2647cd90dcd4867c5eaf5
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.21.jar=cbeb46f443eda928ab19f7955b05aca4
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=728f1691503805567dd8c9a5b7930c21
