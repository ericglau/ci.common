#Wed May 23 16:46:43 EDT 2018
lib/features/com.ibm.websphere.appserver.javax.jsp-2.2.mf=5908c1b586746a60373731d6ee03f4b4
dev/api/spec/com.ibm.websphere.javaee.jsp.2.2_1.0.21.jar=eeb6a3811fab53805ffb35b5a7bf3056
