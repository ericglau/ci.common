#Wed May 23 16:46:43 EDT 2018
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs_1.0.21.jar=f0378d2f5938a9182cec8774ca3f313e
lib/com.ibm.ws.org.apache.commons.lang.2.4_1.0.21.jar=8b8960bacdbfd60ea1680035154dd32f
lib/com.ibm.ws.jaxrs_1.0.21.jar=4f4ae108246eaf02d4fb53344fe7d8c3
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.21.jar=e90b57df8789247b6797eab95f3c2b5a
dev/api/spec/com.ibm.websphere.javaee.jaxrs.1.1_1.0.21.jar=5c4c84db0eb56200d77f3686ae49c90b
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.21.jar=8480e0670488bf3e902149f143034ced
lib/features/com.ibm.websphere.appserver.internal.jaxrs-1.1.mf=49062360d212d34520e4e07ae6c0e21c
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.jaxrs_1.0.21.jar=a3ddad0fdf8e111d9635e3f4840453e2
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs_1.0-javadoc.zip=c4d5cf7a66f2cb775a4bb432dd36de9e
