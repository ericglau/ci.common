#Fri May 04 18:56:44 UTC 2018
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.21.jar=99f7c2563e63382ab19f8ff6220a0bf5
lib/com.ibm.ws.logging.osgi_1.0.21.jar=adedb59eaa7b84dcc298f3c78c779e50
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=0698469d6bb61514fefe6ddb269d56a2
lib/com.ibm.ws.logging_1.0.21.jar=207c6bfbecc1afcc8940fe3575a3d612
lib/com.ibm.ws.collector.manager_1.0.21.jar=bd6d4317818d73a9027d88c5f6f54a3e
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
